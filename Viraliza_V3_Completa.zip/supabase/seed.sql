insert into public.trends(name,category,platform,growth,status,score,description)
values
('Áudio Nostalgia','Música','TikTok',87,'Emergente',97,'Áudios nostálgicos estão ganhando força em vídeos de rotina, moda e storytelling.'),
('Quiet Luxury','Moda','Instagram',64,'Em alta',84,'Conteúdos minimalistas e sofisticados continuam crescendo entre marcas e criadores.'),
('Get Ready With Me','Beauty','TikTok',42,'Em alta',78,'O formato de preparação segue forte para beleza, lifestyle e produtos.'),
('Carrossel Opinião','Conteúdo','Instagram',38,'Emergente',71,'Carrosséis com opinião curta geram salvamentos e comentários.')
on conflict do nothing;
