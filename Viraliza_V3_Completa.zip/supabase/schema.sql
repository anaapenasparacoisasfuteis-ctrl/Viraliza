-- VIRALIZA V3 — banco + autenticação + RLS
-- Execute este arquivo no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'Usuário Viraliza',
  account_type text not null default 'Criador' check (account_type in ('Marca','Criador','Influenciador')),
  avatar_url text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.trends (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'Geral',
  platform text not null default 'Instagram',
  growth integer not null default 0,
  status text not null default 'Emergente',
  score integer not null default 50 check (score between 0 and 100),
  description text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  trend_id uuid references public.trends(id) on delete set null,
  format text not null default 'Post',
  caption text not null default '',
  media_url text,
  likes_count integer not null default 0,
  comments_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id,post_id)
);

create index if not exists posts_created_idx on public.posts(created_at desc);
create index if not exists posts_user_idx on public.posts(user_id);
create index if not exists comments_post_idx on public.comments(post_id);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce((select is_admin from public.profiles where id=auth.uid()),false) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,full_name,account_type)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Usuário Viraliza'),
         coalesce(new.raw_user_meta_data->>'account_type','Criador'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.sync_comment_count()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  update public.posts set comments_count=(select count(*) from public.comments where post_id=coalesce(new.post_id,old.post_id))
  where id=coalesce(new.post_id,old.post_id);
  return coalesce(new,old);
end;
$$;
drop trigger if exists comments_count_trigger on public.comments;
create trigger comments_count_trigger after insert or delete on public.comments
for each row execute procedure public.sync_comment_count();

create or replace function public.toggle_like(p_post_id uuid)
returns void language plpgsql security definer set search_path=public
as $$
begin
  if exists(select 1 from public.likes where user_id=auth.uid() and post_id=p_post_id) then
    delete from public.likes where user_id=auth.uid() and post_id=p_post_id;
  else
    insert into public.likes(user_id,post_id) values(auth.uid(),p_post_id);
  end if;
  update public.posts set likes_count=(select count(*) from public.likes where post_id=p_post_id) where id=p_post_id;
end;
$$;

alter table public.profiles enable row level security;
alter table public.trends enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;

drop policy if exists "profiles read" on public.profiles;
create policy "profiles read" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles own update" on public.profiles;
create policy "profiles own update" on public.profiles for update to authenticated using (id=auth.uid() or public.is_admin()) with check (id=auth.uid() or public.is_admin());

drop policy if exists "trends public read" on public.trends;
create policy "trends public read" on public.trends for select to authenticated using (active=true or public.is_admin());
drop policy if exists "trends admin insert" on public.trends;
create policy "trends admin insert" on public.trends for insert to authenticated with check (public.is_admin());
drop policy if exists "trends admin update" on public.trends;
create policy "trends admin update" on public.trends for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "trends admin delete" on public.trends;
create policy "trends admin delete" on public.trends for delete to authenticated using (public.is_admin());

drop policy if exists "posts read" on public.posts;
create policy "posts read" on public.posts for select to authenticated using (true);
drop policy if exists "posts own insert" on public.posts;
create policy "posts own insert" on public.posts for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "posts own/admin delete" on public.posts;
create policy "posts own/admin delete" on public.posts for delete to authenticated using (user_id=auth.uid() or public.is_admin());

drop policy if exists "comments read" on public.comments;
create policy "comments read" on public.comments for select to authenticated using (true);
drop policy if exists "comments insert" on public.comments;
create policy "comments insert" on public.comments for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "comments own/admin delete" on public.comments;
create policy "comments own/admin delete" on public.comments for delete to authenticated using (user_id=auth.uid() or public.is_admin());

drop policy if exists "likes read" on public.likes;
create policy "likes read" on public.likes for select to authenticated using (true);
drop policy if exists "likes own insert" on public.likes;
create policy "likes own insert" on public.likes for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "likes own delete" on public.likes;
create policy "likes own delete" on public.likes for delete to authenticated using (user_id=auth.uid());

-- Storage: crie manualmente um bucket chamado "post-media" e marque-o como Public.
-- Políticas recomendadas para o bucket:
-- INSERT: authenticated users, pasta inicial igual ao auth.uid()
-- SELECT: public
-- DELETE: dono/admin (pode ser ajustado pelo Storage UI).
